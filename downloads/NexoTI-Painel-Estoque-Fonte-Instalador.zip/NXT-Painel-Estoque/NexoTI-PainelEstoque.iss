#define AppName "Nexo TI - Painel de Estoque"
#define AppVersion "1.0.1"
[Setup]
AppId={{D973492E-D08C-48F9-8D10-1D6D75B46332}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={autopf}\Nexo TI\Painel de Estoque
DisableDirPage=yes
OutputDir=.
OutputBaseFilename=NexoTI-Painel-Estoque-Setup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=admin
WizardStyle=modern
UninstallDisplayName={#AppName}

[Files]
Source: "app\*"; DestDir: "{app}\app"; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "Instalar.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "Iniciar.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "Bandeja.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "Remover.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "LEIA-ME.txt"; DestDir: "{app}"; Flags: ignoreversion

[UninstallRun]
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\Remover.ps1"""; Flags: runhidden waituntilterminated

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
var
  ExitCode: Integer;
begin
  if CurStep = ssPostInstall then begin
    if (not Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
      '-NoProfile -ExecutionPolicy Bypass -File "' + ExpandConstant('{app}\Instalar.ps1') + '"',
      ExpandConstant('{app}'), SW_SHOW, ewWaitUntilTerminated, ExitCode)) or (ExitCode <> 0) then
      RaiseException('A instalacao das dependencias falhou. Verifique a conexao e execute novamente o instalador.');
  end;
end;
