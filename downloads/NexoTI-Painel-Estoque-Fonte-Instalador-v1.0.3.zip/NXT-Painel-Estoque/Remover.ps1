$ErrorActionPreference = 'Stop'
$nome = 'NexoTI-PainelEstoque'
$tarefa = Get-ScheduledTask -TaskName $nome -ErrorAction SilentlyContinue
if ($tarefa) { Stop-ScheduledTask -TaskName $nome -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName $nome -Confirm:$false }
$tray = Get-ScheduledTask -TaskName 'NexoTI-PainelEstoque-Bandeja' -ErrorAction SilentlyContinue
if ($tray) { Unregister-ScheduledTask -TaskName 'NexoTI-PainelEstoque-Bandeja' -Confirm:$false }
Write-Host 'Inicializacao automatica removida. Dados preservados em C:\ProgramData\NexoTI\PainelEstoque.'
