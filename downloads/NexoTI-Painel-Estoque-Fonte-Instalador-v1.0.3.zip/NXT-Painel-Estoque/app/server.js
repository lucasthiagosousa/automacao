const express = require("express");
const fs = require("node:fs");
const path = require("node:path");
const { spawn } = require("node:child_process");

const app = express();
const PORTA = 3000;

const pastaProjeto = __dirname;
const pastaPublica = path.join(pastaProjeto, "public");
const arquivoPlanilha = path.join(
  pastaProjeto,
  "dados",
  "estoque-atual.xlsx"
);
const arquivoAutomacao = path.join(
  pastaProjeto,
  "automacao.js"
);

app.use(express.json());
app.use(express.static(pastaPublica));

let estadoAtualizacao = {
  executando: false,
  sucesso: null,
  mensagem: "Nenhuma atualização executada.",
  inicio: null,
  fim: null,
  log: [],
};

function texto(valor) {
  if (valor === null || valor === undefined) {
    return "";
  }

  return String(valor).trim();
}

function normalizar(valor) {
  return texto(valor)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .trim();
}

function obterLinhas(resultado) {
  if (!Array.isArray(resultado)) {
    return [];
  }

  /*
   * Algumas versões/bibliotecas retornam:
   * [{ sheet: "Sheet", data: [...] }]
   */
  if (
    resultado.length > 0 &&
    resultado[0] &&
    Array.isArray(resultado[0].data)
  ) {
    return resultado[0].data;
  }

  return resultado;
}

function encontrarColuna(cabecalho, nomes) {
  const cabecalhoNormalizado = cabecalho.map(normalizar);

  for (const nome of nomes) {
    const indice = cabecalhoNormalizado.findIndex(
      (coluna) => coluna === normalizar(nome)
    );

    if (indice >= 0) {
      return indice;
    }
  }

  return -1;
}

function valorDaColuna(linha, indice) {
  if (indice < 0 || indice >= linha.length) {
    return "";
  }

  return texto(linha[indice]);
}

function adicionarLog(mensagem) {
  const linhas = String(mensagem)
    .split(/\r?\n/)
    .map((linha) => linha.trim())
    .filter(Boolean);

  for (const linha of linhas) {
    console.log(`[AUTOMAÇÃO] ${linha}`);

    estadoAtualizacao.log.push(linha);

    /*
     * Evita que o histórico cresça indefinidamente.
     */
    if (estadoAtualizacao.log.length > 100) {
      estadoAtualizacao.log.shift();
    }
  }
}

async function lerPlanilha() {
  if (!fs.existsSync(arquivoPlanilha)) {
    throw new Error(
      "A planilha estoque-atual.xlsx ainda não foi encontrada."
    );
  }

  const modulo = await import("read-excel-file/node");
  const readXlsxFile = modulo.default || modulo;

  const resultado = await readXlsxFile(arquivoPlanilha);
  const linhas = obterLinhas(resultado);

  if (!linhas.length) {
    throw new Error("A planilha está vazia.");
  }

  /*
   * Localiza a linha real dos títulos da tabela.
   */
  const indiceCabecalho = linhas.findIndex((linha) => {
    const colunas = linha.map(normalizar);

    return (
      colunas.includes("CODIGO") &&
      colunas.includes("MODELO")
    );
  });

  if (indiceCabecalho < 0) {
    throw new Error(
      "Não foi possível localizar as colunas do relatório NXT4Insight."
    );
  }

  const cabecalho = linhas[indiceCabecalho];

  const colunaProprietario = encontrarColuna(
    cabecalho,
    ["Proprietário", "Proprietario"]
  );

  const colunaAlocado = encontrarColuna(
    cabecalho,
    ["Alocado para"]
  );

  const colunaCodigo = encontrarColuna(
    cabecalho,
    ["Código", "Codigo"]
  );

  const colunaFabricante = encontrarColuna(
    cabecalho,
    ["Fabricante"]
  );

  const colunaMarca = encontrarColuna(
    cabecalho,
    ["Marca"]
  );

  const colunaModelo = encontrarColuna(
    cabecalho,
    ["Modelo"]
  );

  const ativos = [];
  let categoriaAtual = "";

  for (
    let indice = indiceCabecalho + 1;
    indice < linhas.length;
    indice++
  ) {
    const linha = linhas[indice];

    if (!Array.isArray(linha)) {
      continue;
    }

    const conteudoLinha = linha
      .map(texto)
      .filter(Boolean)
      .join(" ");

    /*
     * Exemplo encontrado no relatório:
     * Tipo do ativo: CARREGADOR (Contagem: 13)
     */
    const categoriaEncontrada = conteudoLinha.match(
      /Tipo\s+do\s+ativo\s*:\s*(.+?)(?:\s*\(Contagem\s*:\s*\d+\))?$/i
    );

    if (categoriaEncontrada) {
      categoriaAtual = categoriaEncontrada[1]
        .replace(/\s*\(Contagem.*$/i, "")
        .trim();

      continue;
    }

    if (!categoriaAtual) {
      continue;
    }

    const codigo = valorDaColuna(
      linha,
      colunaCodigo
    );

    const modelo = valorDaColuna(
      linha,
      colunaModelo
    );

    const fabricante = valorDaColuna(
      linha,
      colunaFabricante
    );

    const marca = valorDaColuna(
      linha,
      colunaMarca
    );

    const proprietario = valorDaColuna(
      linha,
      colunaProprietario
    );

    const alocadoPara = valorDaColuna(
      linha,
      colunaAlocado
    );

    /*
     * Ignora linhas de agrupamento, filtros ou linhas vazias.
     */
    if (
      !codigo &&
      !modelo &&
      !fabricante &&
      !marca
    ) {
      continue;
    }

    ativos.push({
      categoria: categoriaAtual,
      proprietario,
      alocadoPara,
      codigo,
      fabricante,
      marca,
      modelo: modelo || "NÃO INFORMADO",
    });
  }

  if (!ativos.length) {
    throw new Error(
      "Nenhum ativo foi encontrado dentro da planilha."
    );
  }

  const mapaCategorias = new Map();

  for (const ativo of ativos) {
    const nomeCategoria =
      ativo.categoria || "SEM CATEGORIA";

    if (!mapaCategorias.has(nomeCategoria)) {
      mapaCategorias.set(nomeCategoria, {
        nome: nomeCategoria,
        atual: 0,
        quantidade: 0,
        modelos: new Map(),
      });
    }

    const categoria = mapaCategorias.get(
      nomeCategoria
    );

    categoria.atual++;
    categoria.quantidade++;

    const nomeModelo =
      ativo.modelo || "NÃO INFORMADO";

    categoria.modelos.set(
      nomeModelo,
      (categoria.modelos.get(nomeModelo) || 0) + 1
    );
  }

  const categorias = Array.from(
    mapaCategorias.values()
  )
    .map((categoria) => ({
      nome: categoria.nome,
      atual: categoria.atual,
      quantidade: categoria.quantidade,
      modelos: Array.from(
        categoria.modelos.entries()
      )
        .map(([nome, quantidade]) => ({
          nome,
          quantidade,
        }))
        .sort(
          (a, b) =>
            b.quantidade - a.quantidade ||
            a.nome.localeCompare(b.nome, "pt-BR")
        ),
    }))
    .sort(
      (a, b) =>
        b.atual - a.atual ||
        a.nome.localeCompare(b.nome, "pt-BR")
    );

  const informacoesArquivo =
    fs.statSync(arquivoPlanilha);

  return {
    sucesso: true,

    /*
     * Campos principais usados pelo dashboard.
     */
    totalAtivos: ativos.length,
    totalCategorias: categorias.length,
    categorias,
    ativos,

    arquivo: {
      nome: path.basename(arquivoPlanilha),
      atualizadoEm:
        informacoesArquivo.mtime.toISOString(),
    },

    /*
     * Campos alternativos para manter compatibilidade
     * com a primeira versão do dashboard.
     */
    total: ativos.length,
    nomeArquivo: path.basename(arquivoPlanilha),
    atualizadoEm:
      informacoesArquivo.mtime.toISOString(),
  };
}

/*
 * Retorna os dados da planilha para o dashboard.
 */
app.get("/api/estoque", async (req, res) => {
  try {
    const dados = await lerPlanilha();

    res.setHeader("Cache-Control", "no-store");
    res.json(dados);
  } catch (erro) {
    console.error(
      "Erro ao ler a planilha:",
      erro.message
    );

    res.status(500).json({
      sucesso: false,
      mensagem: erro.message,
    });
  }
});

/*
 * Informa se a automação ainda está trabalhando.
 */
app.get("/api/atualizacao", (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json(estadoAtualizacao);
});

/*
 * Inicia o Playwright.
 *
 * O dashboard recebe a resposta imediatamente e acompanha
 * o andamento pela rota /api/atualizacao.
 */
app.post("/api/atualizar", (req, res) => {
  if (estadoAtualizacao.executando) {
    return res.status(409).json({
      sucesso: false,
      mensagem: "A atualização já está em andamento.",
    });
  }

  if (!fs.existsSync(arquivoAutomacao)) {
    return res.status(500).json({
      sucesso: false,
      mensagem: "O arquivo automacao.js não foi encontrado.",
    });
  }

  if (
    !process.env.NXT_EMAIL ||
    !process.env.NXT_PASSWORD
  ) {
    return res.status(400).json({
      sucesso: false,
      mensagem:
        "As credenciais do NXT não estão carregadas nesta janela do PowerShell.",
    });
  }

  estadoAtualizacao = {
    executando: true,
    sucesso: null,
    mensagem:
      "Abrindo o NXT4Insight e atualizando a planilha...",
    inicio: new Date().toISOString(),
    fim: null,
    log: [],
  };

  console.log("");
  console.log("Iniciando atualização pelo dashboard...");

  const processo = spawn(
    process.execPath,
    [arquivoAutomacao],
    {
      cwd: pastaProjeto,
      env: process.env,
      windowsHide: true,
      shell: false,
    }
  );

  let finalizado = false;

  const limiteTempo = setTimeout(() => {
    if (finalizado) {
      return;
    }

    adicionarLog(
      "O tempo máximo da automação foi atingido."
    );

    processo.kill();

    estadoAtualizacao = {
      ...estadoAtualizacao,
      executando: false,
      sucesso: false,
      mensagem:
        "A automação ultrapassou o tempo máximo de 15 minutos.",
      fim: new Date().toISOString(),
    };
  }, 15 * 60 * 1000);

  processo.stdout.on("data", (dados) => {
    adicionarLog(dados.toString());
  });

  processo.stderr.on("data", (dados) => {
    adicionarLog(dados.toString());
  });

  processo.on("error", (erro) => {
    finalizado = true;
    clearTimeout(limiteTempo);

    estadoAtualizacao = {
      ...estadoAtualizacao,
      executando: false,
      sucesso: false,
      mensagem: `Não foi possível iniciar a automação: ${erro.message}`,
      fim: new Date().toISOString(),
    };

    console.error(estadoAtualizacao.mensagem);
  });

  processo.on("close", (codigo) => {
    if (finalizado) {
      return;
    }

    finalizado = true;
    clearTimeout(limiteTempo);

    if (codigo === 0) {
      estadoAtualizacao = {
        ...estadoAtualizacao,
        executando: false,
        sucesso: true,
        mensagem:
          "Planilha atualizada com sucesso. Atualizando o dashboard...",
        fim: new Date().toISOString(),
      };

      console.log(
        "Atualização finalizada com sucesso."
      );
    } else {
      estadoAtualizacao = {
        ...estadoAtualizacao,
        executando: false,
        sucesso: false,
        mensagem:
          "A automação não conseguiu concluir o download. Consulte o histórico apresentado no dashboard.",
        fim: new Date().toISOString(),
      };

      console.error(
        `Automação encerrada com o código ${codigo}.`
      );
    }
  });

  return res.status(202).json({
    sucesso: true,
    mensagem: "Atualização iniciada.",
  });
});

/*
 * Se a pessoa digitar uma rota inexistente,
 * retorna o dashboard principal.
 */
app.use((req, res, next) => {
  if (req.method !== "GET") {
    return next();
  }

  res.sendFile(
    path.join(pastaPublica, "index.html")
  );
});

app.listen(PORTA, "127.0.0.1", () => {
  console.log("");
  console.log("Servidor do dashboard iniciado.");
  console.log(`Acesse: http://localhost:${PORTA}`);
  console.log(`Planilha: ${arquivoPlanilha}`);
  console.log("");
});
