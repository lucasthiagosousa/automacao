Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$icone = New-Object System.Windows.Forms.NotifyIcon
$icone.Icon = [System.Drawing.SystemIcons]::Application
$icone.Text = 'Nexo TI - Painel de Estoque'
$icone.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$abrir = $menu.Items.Add('Abrir painel')
$abrir.add_Click({ Start-Process 'http://localhost:3000' })
$status = $menu.Items.Add('Verificar status')
$status.add_Click({
  try {
    $resposta = Invoke-WebRequest 'http://127.0.0.1:3000/' -UseBasicParsing -TimeoutSec 3
    $texto = if ($resposta.StatusCode -eq 200) { 'Painel ativo em http://localhost:3000' } else { 'Painel indisponivel' }
  } catch { $texto = 'Painel indisponivel. Consulte os logs em C:\ProgramData\NexoTI\PainelEstoque\logs.' }
  [System.Windows.Forms.MessageBox]::Show($texto, 'Nexo TI') | Out-Null
})
$sair = $menu.Items.Add('Fechar icone')
$sair.add_Click({ $icone.Visible = $false; [System.Windows.Forms.Application]::Exit() })
$icone.ContextMenuStrip = $menu
$icone.add_DoubleClick({ Start-Process 'http://localhost:3000' })
try { [System.Windows.Forms.Application]::Run() }
finally { $icone.Dispose(); $menu.Dispose() }
