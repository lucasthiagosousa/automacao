$ErrorActionPreference = 'Stop'
$base = Join-Path $env:ProgramData 'NexoTI\PainelEstoque'
$env:PLAYWRIGHT_BROWSERS_PATH = Join-Path $base 'browsers'
$config = Join-Path $base 'credenciais.json'
if (Test-Path $config) {
  $dados = Get-Content $config -Raw | ConvertFrom-Json
  $env:NXT_EMAIL = $dados.email
  $env:NXT_PASSWORD = $dados.password
}
$node = (Get-Content (Join-Path $base 'node-path.txt') -Raw).Trim()
Set-Location (Join-Path $base 'app')
while ($true) {
  try { & $node (Join-Path $base 'app\server.js') *>> (Join-Path $base 'logs\servidor.log') }
  catch { $_ | Out-File (Join-Path $base 'logs\servidor.log') -Append }
  Start-Sleep -Seconds 10
}
