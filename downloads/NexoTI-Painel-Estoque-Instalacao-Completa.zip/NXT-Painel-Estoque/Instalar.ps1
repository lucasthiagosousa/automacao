$ErrorActionPreference = 'Stop'
$principal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Execute este script como Administrador.' }
$origem = Join-Path $PSScriptRoot 'app'
$destino = Join-Path $env:ProgramData 'NexoTI\PainelEstoque'
$nome = 'NexoTI-PainelEstoque'
if (-not (Test-Path (Join-Path $origem 'package-lock.json'))) { throw 'package-lock.json nao encontrado.' }
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
New-Item -ItemType Directory -Force $destino | Out-Null
$runtime = Join-Path $destino 'runtime'
$node = Join-Path $runtime 'node.exe'
if (-not (Test-Path $node)) {
  Write-Host 'Baixando Node.js LTS para Windows x64...'
  $lista = Invoke-RestMethod 'https://nodejs.org/dist/index.json'
  $release = $lista | Where-Object { $_.lts -and ([int]($_.version -replace '^v(\d+)\..*','$1') -ge 20) -and ($_.files -contains 'win-x64-zip') } | Select-Object -First 1
  if (-not $release) { throw 'Nao foi encontrada uma versao Node.js LTS Windows x64.' }
  $nomeArquivo = "node-$($release.version)-win-x64.zip"
  $urlBase = "https://nodejs.org/dist/$($release.version)"
  $tempZip = Join-Path $env:TEMP $nomeArquivo
  Invoke-WebRequest "$urlBase/$nomeArquivo" -OutFile $tempZip -UseBasicParsing
  $somas = (Invoke-WebRequest "$urlBase/SHASUMS256.txt" -UseBasicParsing).Content
  $linha = ($somas -split "`n" | Where-Object { $_ -match ('\s+' + [regex]::Escape($nomeArquivo) + '\s*$') } | Select-Object -First 1)
  if (-not $linha) { throw 'Checksum do Node.js nao encontrado.' }
  $esperado = ($linha.Trim() -split '\s+')[0].ToLowerInvariant()
  $real = (Get-FileHash -Path $tempZip -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($real -ne $esperado) { throw 'Checksum do Node.js nao confere; download interrompido.' }
  $extracao = Join-Path $env:TEMP ('nexo-node-' + [guid]::NewGuid().ToString('N'))
  Expand-Archive -Path $tempZip -DestinationPath $extracao
  $pastaNode = Join-Path $extracao ("node-$($release.version)-win-x64")
  Move-Item $pastaNode $runtime
  Remove-Item $extracao -Recurse -Force
  Remove-Item $tempZip -Force
}
if (-not (Test-Path $node)) { throw 'Node.js nao instalado corretamente.' }
$versao = & $node -p 'process.versions.node.split(".")[0]'
if ([int]$versao -lt 20) { throw 'Node.js 20 ou superior necessario.' }
$tarefa = Get-ScheduledTask -TaskName $nome -ErrorAction SilentlyContinue
if ($tarefa) { Stop-ScheduledTask -TaskName $nome -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName $nome -Confirm:$false }
if (Test-Path (Join-Path $destino 'app')) {
  $backup = Join-Path $destino ('backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
  Move-Item (Join-Path $destino 'app') $backup
}
Copy-Item $origem (Join-Path $destino 'app') -Recurse -Force
New-Item -ItemType Directory -Force (Join-Path $destino 'logs') | Out-Null
$app = Join-Path $destino 'app'
$env:PATH = "$runtime;$env:PATH"
Push-Location $app
try {
  Write-Host 'Baixando dependencias conforme package-lock.json...'
  & (Join-Path $runtime 'npm.cmd') ci --omit=dev --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw 'npm ci falhou. Verifique conexao com registry.npmjs.org.' }
  & $node -e "require('express'); require('playwright'); require('read-excel-file/node')"
  if ($LASTEXITCODE -ne 0) { throw 'Dependencias Node.js incompletas.' }
} finally { Pop-Location }
$config = Join-Path $destino 'credenciais.json'
if (-not (Test-Path $config)) {
  $email = Read-Host 'Email de acesso ao NXT4Insight (Enter para configurar depois)'
  if ($email) {
    $senhaSegura = Read-Host 'Senha do NXT4Insight' -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($senhaSegura)
    try { $senha = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    @{ email = $email; password = $senha } | ConvertTo-Json | Set-Content -Path $config -Encoding UTF8
    $senha = $null
    & icacls.exe $config /inheritance:r /grant:r '*S-1-5-18:F' '*S-1-5-32-544:F' | Out-Null
  }
}
$runner = Join-Path $destino 'Iniciar.ps1'
Copy-Item (Join-Path $PSScriptRoot 'Iniciar.ps1') $runner -Force
$node | Set-Content -Path (Join-Path $destino 'node-path.txt') -Encoding ASCII
$browserPath = Join-Path $destino 'browsers'
$env:PLAYWRIGHT_BROWSERS_PATH = $browserPath
$playwrightCli = Join-Path $destino 'app\node_modules\playwright\cli.js'
Write-Host 'Baixando Chromium do Playwright...'
& $node $playwrightCli install chromium
if ($LASTEXITCODE -ne 0) { throw 'Falha ao instalar Chromium. Verifique acesso a internet e execute Instalar.ps1 novamente.' }
$acao = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $runner + '"') -WorkingDirectory $destino
$gatilho = New-ScheduledTaskTrigger -AtStartup
$conta = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$opcoes = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Seconds 0) -StartWhenAvailable
Register-ScheduledTask -TaskName $nome -Action $acao -Trigger $gatilho -Principal $conta -Settings $opcoes -Force | Out-Null
Start-ScheduledTask -TaskName $nome
Start-Sleep -Seconds 3
Get-ScheduledTaskInfo -TaskName $nome | Select-Object LastRunTime,LastTaskResult
Write-Host "Instalacao concluida. Abra http://localhost:3000 no servidor. Logs: $destino\logs"
